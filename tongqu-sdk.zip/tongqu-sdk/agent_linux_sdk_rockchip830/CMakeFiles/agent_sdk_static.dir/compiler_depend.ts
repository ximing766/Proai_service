# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for agent_sdk_static.
