#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
export SDK_PROFILE="${SDK_PROFILE:-rockchip830}"
export SDK_LIBRARY="${SDK_LIBRARY:-${SCRIPT_DIR}/lib/libagent_sdk.so}"
export LD_LIBRARY_PATH="${SCRIPT_DIR}/lib:${LD_LIBRARY_PATH:-}"

exec bash "${SCRIPT_DIR}/scripts/sdk_voice_demo_remote.sh" "$@"
