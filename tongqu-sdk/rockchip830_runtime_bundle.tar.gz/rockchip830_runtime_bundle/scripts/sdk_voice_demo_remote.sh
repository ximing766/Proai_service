#!/usr/bin/env bash
# 面向局域网或公网部署地址的 SDK 语音链路验证脚本。
#
# 文件: scripts/sdk_voice_demo_remote.sh
# 作者: hh-zyb

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
PYTHON_DEMO="${ROOT_DIR}/tools/sdk_voice_demo/sdk_voice_chat_demo.py"
SDK_PROFILE="${SDK_PROFILE:-auto}"
SDK_LIBRARY="${SDK_LIBRARY:-}"
SDK_NATIVE_LIBRARY="${ROOT_DIR}/agent_linux_sdk/build_wsl_docker/libagent_sdk.so"
SDK_CROSS_LIBRARY="${ROOT_DIR}/Cross/compilation/output/rockchip830/libagent_sdk.so"
SDK_PACKAGE_LIBRARY="${ROOT_DIR}/lib/libagent_sdk.so"
OUTPUT_ROOT="${OUTPUT_ROOT:-${ROOT_DIR}/runtime_logs/sdk_voice_demo_remote}"
WS_URL="${AGENT_WS_URL:-}"
API_BASE_URL="${VOICE_DEMO_API_BASE_URL:-}"
DEVICE_ID="${VOICE_DEMO_DEVICE_ID:-}"
DEVICE_SECRET="${VOICE_DEMO_DEVICE_SECRET:-}"
CLIENT_ID="${VOICE_DEMO_CLIENT_ID:-voice-demo-client-001}"
AUTHORIZATION="${VOICE_DEMO_AUTHORIZATION:-}"
AGENT_ID="${VOICE_DEMO_AGENT_ID:-}"
USER_ID="${VOICE_DEMO_USER_ID:-}"
TTS_TONE_ID="${VOICE_DEMO_TTS_TONE_ID:-}"
SOURCE_NAME="${SDK_AUDIO_SOURCE:-}"
SINK_NAME="${SDK_AUDIO_SINK:-}"
CONNECT_TIMEOUT="${CONNECT_TIMEOUT:-10}"
TURN_TIMEOUT="${TURN_TIMEOUT:-60}"
RECORD_SECONDS="${RECORD_SECONDS:-0}"
CHUNK_DURATION_MS="${CHUNK_DURATION_MS:-20}"
SEND_PACE_MS="${SEND_PACE_MS:-20}"
PCM_FILE=""
WAV_FILE=""
SYNTHETIC_INPUT="0"
SYNTHETIC_SECONDS="${SYNTHETIC_SECONDS:-1.2}"
NO_PLAYBACK="0"
LIST_DEVICES="0"
BUILD_SDK_IF_NEEDED="1"
ONCE="auto"
ENSURE_DEVICE_AUTH="0"
CHECK_ACTIVATION_ONLY="0"
FETCH_PAIRING_CODE_ONLY="0"
FETCH_DEVICE_TOKEN_ONLY="0"
AUTO_DEVICE_FLOW="0"
PAIRING_WAIT_TIMEOUT="${PAIRING_WAIT_TIMEOUT:-300}"
PAIRING_POLL_INTERVAL="${PAIRING_POLL_INTERVAL:-3}"
TMP_DIR=""

log() {
  echo "[sdk-voice-demo-remote] $*"
}

usage() {
  cat <<'EOF'
用法:
  bash scripts/sdk_voice_demo_remote.sh --ws-url <ws://host:8765/ws/v1/chat|wss://domain/ws/v1/chat> [选项]

常用示例:
  1. 局域网直连 + PCM 文件验证:
     bash scripts/sdk_voice_demo_remote.sh \
       --ws-url ws://192.168.1.90:8765/ws/v1/chat \
       --pcm-file /path/to/demo_input.pcm

  2. 公网 TLS + WAV 文件验证:
     bash scripts/sdk_voice_demo_remote.sh \
       --ws-url wss://demo.example.com/ws/v1/chat \
       --wav-file /path/to/demo_input.wav \
       --no-playback

  3. 本机麦克风演示:
     bash scripts/sdk_voice_demo_remote.sh \
       --ws-url ws://127.0.0.1:8765/ws/v1/chat \
       --record-seconds 5 \
       --source-name <Pulse源> \
       --sink-name <Pulse输出>

参数:
  --ws-url <url>             目标 WebSocket 地址，支持 ws:// 或 wss://
  --pcm-file <path>          输入 PCM 文件，要求 16kHz/单声道/16bit little-endian
  --wav-file <path>          输入 WAV 文件，要求 PCM 编码、16kHz、单声道、16bit
  --record-seconds <sec>     使用麦克风录音演示，录音秒数大于 0
  --synthetic-input          使用脚本内合成音频做链路连通性测试
  --synthetic-seconds <sec>  合成音频时长，默认 1.2 秒
  --sdk-library <path>      指定本地 libagent_sdk.so 路径
  --sdk-profile <name>      SDK 档位：auto、native、rockchip830
  --output-root <path>      指定日志输出根目录
  --api-base-url <url>      指定 manager-api / nginx HTTP 基础地址，留空时根据 ws-url 自动推导
  --device-id <id>           设备 ID
  --device-secret <secret>   设备密钥，用于检查激活状态、申请配对码、换取 token
  --client-id <id>           客户端 ID
  --agent-id <id>            Agent ID
  --user-id <id>             User ID
  --authorization <value>    Authorization 头
  --tts-tone-id <id>         TTS 音色 ID
  --source-name <name>       Pulse 录音源名称
  --sink-name <name>         Pulse 播放输出名称
  --connect-timeout <sec>    SDK 连接超时，默认 10
  --turn-timeout <sec>       单轮回复超时，默认 60
  --chunk-duration-ms <ms>   音频分片时长，默认 20
  --send-pace-ms <ms>        音频发送节奏，默认 20
  --no-playback              不播放返回音频，只保留日志
  --list-devices             列出 Pulse 输入输出设备
  --check-activation-only    仅检查设备激活状态
  --fetch-pairing-code-only  仅申请设备配对码
  --fetch-device-token-only  仅获取设备 token
  --ensure-device-auth       建连前自动检查激活状态并获取设备 token
  --auto-device-flow         自动检查绑定状态、申请配对码并等待用户完成绑定
  --pairing-wait-timeout <s> 等待用户绑定超时，默认 300 秒
  --pairing-poll-interval <s>轮询绑定状态间隔，默认 3 秒
  --once                     仅执行一轮对话后退出
  --skip-build               若本地没有 libagent_sdk.so，不自动构建
  --keep-loop                连续交互，不强制 once
  --help                     显示帮助
EOF
}

resolve_sdk_library() {
  if [ -n "${SDK_LIBRARY}" ]; then
    return 0
  fi

  case "${SDK_PROFILE}" in
    auto)
      for t_candidate in "${SDK_PACKAGE_LIBRARY}" "${SDK_CROSS_LIBRARY}" "${SDK_NATIVE_LIBRARY}"; do
        if [ -f "${t_candidate}" ]; then
          SDK_LIBRARY="${t_candidate}"
          return 0
        fi
      done
      ;;
    native)
      if [ -f "${SDK_NATIVE_LIBRARY}" ]; then
        SDK_LIBRARY="${SDK_NATIVE_LIBRARY}"
        return 0
      fi
      ;;
    rockchip830)
      for t_candidate in "${SDK_PACKAGE_LIBRARY}" "${SDK_CROSS_LIBRARY}"; do
        if [ -f "${t_candidate}" ]; then
          SDK_LIBRARY="${t_candidate}"
          return 0
        fi
      done
      ;;
    *)
      log "不支持的 --sdk-profile: ${SDK_PROFILE}"
      exit 1
      ;;
  esac

  return 1
}

build_sdk_if_needed() {
  if [ "${BUILD_SDK_IF_NEEDED}" != "1" ]; then
    log "找不到 SDK 动态库: ${SDK_LIBRARY:-<auto unresolved>}"
    exit 1
  fi

  if [ "${SDK_PROFILE}" = "rockchip830" ]; then
    if [ ! -f "${ROOT_DIR}/Cross/compilation/build_agent_linux_sdk_rockchip830.sh" ]; then
      log "缺少 rockchip830 交叉编译脚本，无法自动构建: ${ROOT_DIR}/Cross/compilation/build_agent_linux_sdk_rockchip830.sh"
      exit 1
    fi
    log "缺少 rockchip830 SDK 动态库，开始交叉编译"
    bash "${ROOT_DIR}/Cross/compilation/build_agent_linux_sdk_rockchip830.sh"
  else
    log "本地缺少 libagent_sdk.so，开始构建"
    bash "${ROOT_DIR}/scripts/build_agent_sdk_wsl.sh"
  fi

  if ! resolve_sdk_library; then
    log "构建后仍未找到 SDK 动态库"
    exit 1
  fi
}

prepare_sdk_runtime() {
  local t_sdk_dir=""
  t_sdk_dir="$(cd "$(dirname "${SDK_LIBRARY}")" && pwd)"
  export LD_LIBRARY_PATH="${t_sdk_dir}:${LD_LIBRARY_PATH:-}"
}

require_command() {
  if ! command -v "$1" >/dev/null 2>&1; then
    log "缺少命令: $1"
    exit 1
  fi
}

cleanup() {
  if [ -n "${TMP_DIR}" ] && [ -d "${TMP_DIR}" ]; then
    rm -rf "${TMP_DIR}"
  fi
}
trap cleanup EXIT

while [ $# -gt 0 ]; do
  case "$1" in
    --ws-url)
      WS_URL="${2:-}"
      shift 2
      ;;
    --sdk-library)
      SDK_LIBRARY="${2:-}"
      shift 2
      ;;
    --sdk-profile)
      SDK_PROFILE="${2:-auto}"
      shift 2
      ;;
    --output-root)
      OUTPUT_ROOT="${2:-}"
      shift 2
      ;;
    --api-base-url)
      API_BASE_URL="${2:-}"
      shift 2
      ;;
    --pcm-file)
      PCM_FILE="${2:-}"
      shift 2
      ;;
    --wav-file)
      WAV_FILE="${2:-}"
      shift 2
      ;;
    --record-seconds)
      RECORD_SECONDS="${2:-0}"
      shift 2
      ;;
    --synthetic-input)
      SYNTHETIC_INPUT="1"
      shift
      ;;
    --synthetic-seconds)
      SYNTHETIC_SECONDS="${2:-1.2}"
      shift 2
      ;;
    --device-id)
      DEVICE_ID="${2:-}"
      shift 2
      ;;
    --device-secret)
      DEVICE_SECRET="${2:-}"
      shift 2
      ;;
    --client-id)
      CLIENT_ID="${2:-}"
      shift 2
      ;;
    --authorization)
      AUTHORIZATION="${2:-}"
      shift 2
      ;;
    --agent-id)
      AGENT_ID="${2:-}"
      shift 2
      ;;
    --user-id)
      USER_ID="${2:-}"
      shift 2
      ;;
    --tts-tone-id)
      TTS_TONE_ID="${2:-}"
      shift 2
      ;;
    --source-name)
      SOURCE_NAME="${2:-}"
      shift 2
      ;;
    --sink-name)
      SINK_NAME="${2:-}"
      shift 2
      ;;
    --connect-timeout)
      CONNECT_TIMEOUT="${2:-10}"
      shift 2
      ;;
    --turn-timeout)
      TURN_TIMEOUT="${2:-60}"
      shift 2
      ;;
    --chunk-duration-ms)
      CHUNK_DURATION_MS="${2:-20}"
      shift 2
      ;;
    --send-pace-ms)
      SEND_PACE_MS="${2:-20}"
      shift 2
      ;;
    --no-playback)
      NO_PLAYBACK="1"
      shift
      ;;
    --list-devices)
      LIST_DEVICES="1"
      shift
      ;;
    --check-activation-only)
      CHECK_ACTIVATION_ONLY="1"
      shift
      ;;
    --fetch-pairing-code-only)
      FETCH_PAIRING_CODE_ONLY="1"
      shift
      ;;
    --fetch-device-token-only)
      FETCH_DEVICE_TOKEN_ONLY="1"
      shift
      ;;
    --ensure-device-auth)
      ENSURE_DEVICE_AUTH="1"
      shift
      ;;
    --auto-device-flow)
      AUTO_DEVICE_FLOW="1"
      shift
      ;;
    --pairing-wait-timeout)
      PAIRING_WAIT_TIMEOUT="${2:-300}"
      shift 2
      ;;
    --pairing-poll-interval)
      PAIRING_POLL_INTERVAL="${2:-3}"
      shift 2
      ;;
    --once)
      ONCE="1"
      shift
      ;;
    --skip-build)
      BUILD_SDK_IF_NEEDED="0"
      shift
      ;;
    --keep-loop)
      ONCE="0"
      shift
      ;;
    --help|-h)
      usage
      exit 0
      ;;
    *)
      log "未知参数: $1"
      usage
      exit 1
      ;;
  esac
done

require_command python3

if [ ! -f "${PYTHON_DEMO}" ]; then
  log "找不到 Python Demo: ${PYTHON_DEMO}"
  exit 1
fi

if [ -z "${WS_URL}" ]; then
  log "必须提供 --ws-url 或环境变量 AGENT_WS_URL"
  usage
  exit 1
fi

case "${WS_URL}" in
  ws://*|wss://*) ;;
  *)
    log "ws-url 必须以 ws:// 或 wss:// 开头"
    exit 1
    ;;
esac

if ! resolve_sdk_library; then
  build_sdk_if_needed
fi

if [ ! -f "${SDK_LIBRARY}" ]; then
  log "找不到 SDK 动态库: ${SDK_LIBRARY}"
  exit 1
fi

prepare_sdk_runtime

if [ -n "${DEVICE_SECRET}" ] && [ -z "${AUTHORIZATION}" ] && [ "${ENSURE_DEVICE_AUTH}" = "0" ]; then
  ENSURE_DEVICE_AUTH="1"
fi

if [ -n "${DEVICE_SECRET}" ] && [ "${AUTO_DEVICE_FLOW}" = "0" ] \
  && [ "${CHECK_ACTIVATION_ONLY}" != "1" ] \
  && [ "${FETCH_PAIRING_CODE_ONLY}" != "1" ] \
  && [ "${FETCH_DEVICE_TOKEN_ONLY}" != "1" ]; then
  AUTO_DEVICE_FLOW="1"
fi

INPUT_COUNT=0
if [ -n "${PCM_FILE}" ]; then INPUT_COUNT=$((INPUT_COUNT + 1)); fi
if [ -n "${WAV_FILE}" ]; then INPUT_COUNT=$((INPUT_COUNT + 1)); fi
if [ "${SYNTHETIC_INPUT}" = "1" ]; then INPUT_COUNT=$((INPUT_COUNT + 1)); fi
case "${RECORD_SECONDS}" in
  ''|'0'|'0.0'|'0.00') ;;
  *) INPUT_COUNT=$((INPUT_COUNT + 1)) ;;
esac

CONTROL_ONLY_MODE="0"
if [ "${CHECK_ACTIVATION_ONLY}" = "1" ] || [ "${FETCH_PAIRING_CODE_ONLY}" = "1" ] || [ "${FETCH_DEVICE_TOKEN_ONLY}" = "1" ]; then
  CONTROL_ONLY_MODE="1"
fi

if [ "${LIST_DEVICES}" != "1" ] && [ "${CONTROL_ONLY_MODE}" != "1" ]; then
  if [ "${INPUT_COUNT}" -eq 0 ]; then
    if [ -t 0 ]; then
      log "未指定输入源，默认进入交互式麦克风多轮演示"
    else
      log "非交互模式下必须指定输入方式：--pcm-file、--wav-file、--record-seconds 或 --synthetic-input"
      exit 1
    fi
  elif [ "${INPUT_COUNT}" -ne 1 ]; then
    log "必须且只能选择一种输入方式：--pcm-file、--wav-file、--record-seconds 或 --synthetic-input"
    exit 1
  fi
fi

if [ -n "${PCM_FILE}" ] && [ ! -f "${PCM_FILE}" ]; then
  log "PCM 文件不存在: ${PCM_FILE}"
  exit 1
fi

if [ -n "${WAV_FILE}" ] && [ ! -f "${WAV_FILE}" ]; then
  log "WAV 文件不存在: ${WAV_FILE}"
  exit 1
fi

INPUT_PCM_FILE="${PCM_FILE}"
if [ -n "${WAV_FILE}" ]; then
  TMP_DIR="$(mktemp -d "${ROOT_DIR}/.tmp_sdk_voice_demo_remote.XXXXXX")"
  INPUT_PCM_FILE="${TMP_DIR}/input_from_wav.pcm"
  log "将 WAV 转换为 PCM: ${WAV_FILE} -> ${INPUT_PCM_FILE}"
  python3 - "${WAV_FILE}" "${INPUT_PCM_FILE}" <<'PY'
import pathlib
import sys
import wave

wav_path = pathlib.Path(sys.argv[1]).expanduser().resolve()
out_path = pathlib.Path(sys.argv[2]).expanduser().resolve()
with wave.open(str(wav_path), 'rb') as wav_file:
    channels = wav_file.getnchannels()
    sample_width = wav_file.getsampwidth()
    sample_rate = wav_file.getframerate()
    compression = wav_file.getcomptype()
    if channels != 1 or sample_width != 2 or sample_rate != 16000 or compression != 'NONE':
        raise SystemExit(
            f'WAV 格式不受支持: channels={channels}, sample_width={sample_width}, sample_rate={sample_rate}, compression={compression}; '
            '当前仅支持 PCM 编码、16kHz、单声道、16bit 的 WAV 文件。'
        )
    out_path.write_bytes(wav_file.readframes(wav_file.getnframes()))
PY
fi

STAMP="$(date +%Y%m%d_%H%M%S)"
LOG_DIR="${OUTPUT_ROOT}/${STAMP}"
mkdir -p "${LOG_DIR}"
LOG_FILE="${LOG_DIR}/sdk_voice_demo_remote.log"

CMD=(python3 -u "${PYTHON_DEMO}"
  --sdk-library "${SDK_LIBRARY}"
  --ws-url "${WS_URL}"
  --api-base-url "${API_BASE_URL}"
  --device-id "${DEVICE_ID}"
  --device-secret "${DEVICE_SECRET}"
  --client-id "${CLIENT_ID}"
  --authorization "${AUTHORIZATION}"
  --agent-id "${AGENT_ID}"
  --user-id "${USER_ID}"
  --tts-tone-id "${TTS_TONE_ID}"
  --source-name "${SOURCE_NAME}"
  --sink-name "${SINK_NAME}"
  --connect-timeout "${CONNECT_TIMEOUT}"
  --turn-timeout "${TURN_TIMEOUT}"
  --chunk-duration-ms "${CHUNK_DURATION_MS}"
  --send-pace-ms "${SEND_PACE_MS}")

if [ -n "${INPUT_PCM_FILE}" ]; then
  CMD+=(--pcm-file "${INPUT_PCM_FILE}")
fi
if [ "${SYNTHETIC_INPUT}" = "1" ]; then
  CMD+=(--synthetic-input --synthetic-seconds "${SYNTHETIC_SECONDS}")
fi
case "${RECORD_SECONDS}" in
  ''|'0'|'0.0'|'0.00') ;;
  *) CMD+=(--record-seconds "${RECORD_SECONDS}") ;;
esac
if [ "${LIST_DEVICES}" = "1" ]; then
  CMD+=(--list-devices)
fi
if [ "${CHECK_ACTIVATION_ONLY}" = "1" ]; then
  CMD+=(--check-activation-only)
fi
if [ "${FETCH_PAIRING_CODE_ONLY}" = "1" ]; then
  CMD+=(--fetch-pairing-code-only)
fi
if [ "${FETCH_DEVICE_TOKEN_ONLY}" = "1" ]; then
  CMD+=(--fetch-device-token-only)
fi
if [ "${AUTO_DEVICE_FLOW}" = "1" ]; then
  CMD+=(--auto-device-flow --pairing-wait-timeout "${PAIRING_WAIT_TIMEOUT}" --pairing-poll-interval "${PAIRING_POLL_INTERVAL}")
fi
if [ "${ENSURE_DEVICE_AUTH}" = "1" ]; then
  CMD+=(--ensure-device-auth)
fi
if [ "${NO_PLAYBACK}" = "1" ]; then
  CMD+=(--no-playback)
fi
if [ "${ONCE}" = "1" ]; then
  CMD+=(--once)
elif [ "${ONCE}" = "auto" ] && [ "${INPUT_COUNT}" -eq 1 ] && { [ -n "${INPUT_PCM_FILE}" ] || [ "${SYNTHETIC_INPUT}" = "1" ] || ! [ -t 0 ]; }; then
  CMD+=(--once)
fi

log "ws_url=${WS_URL}"
log "sdk_profile=${SDK_PROFILE}"
log "sdk_library=${SDK_LIBRARY}"
log "log_file=${LOG_FILE}"
log "command=${CMD[*]}"

set +e
"${CMD[@]}" 2>&1 | tee "${LOG_FILE}"
STATUS=${PIPESTATUS[0]}
set -e

if [ "${STATUS}" -ne 0 ]; then
  log "语音链路验证失败，日志保存在: ${LOG_FILE}"
  exit "${STATUS}"
fi

log "语音链路验证完成，日志保存在: ${LOG_FILE}"
log "建议检查关键输出：asr_final、assistant_text、tts_stream_end、turn summary"
