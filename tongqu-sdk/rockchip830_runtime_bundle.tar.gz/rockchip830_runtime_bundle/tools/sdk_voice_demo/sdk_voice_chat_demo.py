#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
童趣 SDK 语音演示程序
作者: hh-zyb
功能:
    - 通过 SDK 连接童趣云端语音服务
    - 使用 ctypes 加载本地 libagent_sdk.so
    - 使用 parec / pacat 访问本地音频设备
    - 验证 SDK -> tongqu_server -> 阿里云 ASR/LLM/TTS 的整条语音链路
"""

from __future__ import annotations

import argparse
import ctypes
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time
from typing import Any


AGENT_STATUS_DISCONNECTED = 0
AGENT_STATUS_CONNECTING = 1
AGENT_STATUS_CONNECTED = 2

PCM_SAMPLE_RATE = 16000
PCM_CHANNELS = 1
PCM_SAMPLE_WIDTH_BYTES = 2
PCM_FRAME_DURATION_MS = 20
PCM_FRAME_BYTES = int(PCM_SAMPLE_RATE * PCM_CHANNELS * PCM_SAMPLE_WIDTH_BYTES * PCM_FRAME_DURATION_MS / 1000)
DEVICE_ID_MAX_LENGTH = 65
STATUS_TEXT_MAX_LENGTH = 32
PAIRING_CODE_MAX_LENGTH = 32
TIMESTAMP_TEXT_MAX_LENGTH = 64
TOKEN_TYPE_MAX_LENGTH = 32
ACCESS_TOKEN_MAX_LENGTH = 2048


class AgentConfig(ctypes.Structure):
    """
    `AgentConfig` 类。

    功能:
        封装与 `AgentConfig` 相关的职责。
    """
    _fields_ = [
        ("ws_url", ctypes.c_char_p),
        ("device_id", ctypes.c_char_p),
        ("client_id", ctypes.c_char_p),
        ("authorization", ctypes.c_char_p),
        ("agent_id", ctypes.c_char_p),
        ("user_id", ctypes.c_char_p),
        ("tts_tone_id", ctypes.c_char_p),
        ("audio_format", ctypes.c_char_p),
        ("sample_rate", ctypes.c_int),
        ("channels", ctypes.c_int),
        ("frame_duration_ms", ctypes.c_int),
        ("feature_iot", ctypes.c_int),
        ("feature_speaker", ctypes.c_int),
        ("feature_mcp", ctypes.c_int),
    ]


class AgentDeviceActivationStatus(ctypes.Structure):
    _fields_ = [
        ("m_device_id", ctypes.c_char * DEVICE_ID_MAX_LENGTH),
        ("m_status", ctypes.c_char * STATUS_TEXT_MAX_LENGTH),
        ("m_setup_status", ctypes.c_char * STATUS_TEXT_MAX_LENGTH),
        ("m_current_agent_id", ctypes.c_char * DEVICE_ID_MAX_LENGTH),
        ("m_activated_flag", ctypes.c_int),
        ("m_bound_flag", ctypes.c_int),
        ("m_can_request_pairing_code_flag", ctypes.c_int),
    ]


class AgentDevicePairingCodeResult(ctypes.Structure):
    _fields_ = [
        ("m_device_id", ctypes.c_char * DEVICE_ID_MAX_LENGTH),
        ("m_pairing_code", ctypes.c_char * PAIRING_CODE_MAX_LENGTH),
        ("m_pairing_expires_at", ctypes.c_char * TIMESTAMP_TEXT_MAX_LENGTH),
        ("m_status", ctypes.c_char * STATUS_TEXT_MAX_LENGTH),
        ("m_scene", ctypes.c_char * STATUS_TEXT_MAX_LENGTH),
    ]


class AgentDeviceTokenResult(ctypes.Structure):
    _fields_ = [
        ("m_token_type", ctypes.c_char * TOKEN_TYPE_MAX_LENGTH),
        ("m_access_token", ctypes.c_char * ACCESS_TOKEN_MAX_LENGTH),
        ("m_expires_in", ctypes.c_long),
        ("m_device_id", ctypes.c_char * DEVICE_ID_MAX_LENGTH),
    ]


MessageCallbackType = ctypes.CFUNCTYPE(None, ctypes.c_char_p, ctypes.c_void_p)
AudioCallbackType = ctypes.CFUNCTYPE(None, ctypes.POINTER(ctypes.c_ubyte), ctypes.c_size_t, ctypes.c_void_p)
StatusCallbackType = ctypes.CFUNCTYPE(None, ctypes.c_int, ctypes.c_void_p)
ErrorCallbackType = ctypes.CFUNCTYPE(None, ctypes.c_int, ctypes.c_char_p, ctypes.c_void_p)


class AudioPlaybackStream:
    """
    使用 `pacat` 播放 TTS 返回的 PCM 音频。

    SDK 只负责把二进制音频回调给 Demo，真正的播放由这里负责。
    """

    def __init__(self, f_sink_name: str, f_enabled: bool) -> None:
        """
        初始化 AudioPlaybackStream，并保存运行所需依赖。

        参数:
            f_sink_name: sink名称。
            f_enabled: enabled。
        """
        self.m_sink_name = f_sink_name.strip()
        self.m_enabled = f_enabled
        self.m_process: subprocess.Popen[bytes] | None = None
        self.m_lock = threading.Lock()
        self.m_last_error = ""

    def isEnabled(self) -> bool:
        """
        返回当前播放是否启用。
        """
        return self.m_enabled

    def getSinkName(self) -> str:
        """
        返回当前播放 sink 名称。
        """
        return self.m_sink_name

    def getLastError(self) -> str:
        """
        返回最近一次播放错误。
        """
        return self.m_last_error

    def _buildPlaybackCommand(self) -> list[str]:
        """
        构建 `pacat` 播放命令。
        """
        t_command = [
            "pacat",
            "--playback",
            "--raw",
            "--format=s16le",
            f"--rate={PCM_SAMPLE_RATE}",
            f"--channels={PCM_CHANNELS}",
        ]
        if self.m_sink_name:
            t_command.extend(["--device", self.m_sink_name])
        return t_command

    def _consumeProcessErrorLocked(self) -> str:
        """
        读取并缓存播放进程错误输出。
        """
        if self.m_process is None or self.m_process.stderr is None:
            return self.m_last_error
        try:
            t_error = self.m_process.stderr.read().decode("utf-8", errors="replace").strip()
        except Exception:
            t_error = ""
        self.m_last_error = t_error
        return self.m_last_error

    def start(self) -> None:
        """
        处理start。
        """
        if not self.m_enabled:
            return
        with self.m_lock:
            if self.m_process is not None:
                return
            t_command = self._buildPlaybackCommand()
            self.m_process = subprocess.Popen(
                t_command,
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
            )
            time.sleep(0.05)
            t_return_code = self.m_process.poll()
            if t_return_code is None:
                self.m_last_error = ""
                return
            t_error = self._consumeProcessErrorLocked()
            self.m_process = None
            raise RuntimeError(
                "pacat start failed: "
                + (t_error or f"exit_code={t_return_code}")
            )

    def write(self, f_audio_bytes: bytes) -> None:
        """
        处理write。

        参数:
            f_audio_bytes: 待处理的音频字节数据。
        """
        if not self.m_enabled or not f_audio_bytes:
            return
        with self.m_lock:
            if self.m_process is None or self.m_process.stdin is None:
                return
            t_return_code = self.m_process.poll()
            if t_return_code is not None:
                t_error = self._consumeProcessErrorLocked()
                self.m_process = None
                raise RuntimeError(
                    "pacat exited before playback write: "
                    + (t_error or f"exit_code={t_return_code}")
                )
            self.m_process.stdin.write(f_audio_bytes)
            self.m_process.stdin.flush()

    def finish(self) -> None:
        """
        结束当前流式处理并返回最终结果。
        """
        if not self.m_enabled:
            return
        with self.m_lock:
            if self.m_process is None:
                return
            try:
                if self.m_process.stdin is not None:
                    self.m_process.stdin.close()
                t_return_code = self.m_process.wait(timeout=10.0)
                if t_return_code != 0:
                    t_error = self._consumeProcessErrorLocked()
                    raise RuntimeError(
                        "pacat finish failed: "
                        + (t_error or f"exit_code={t_return_code}")
                    )
                self._consumeProcessErrorLocked()
            finally:
                self.m_process = None

    def abort(self) -> None:
        """
        处理abort。
        """
        with self.m_lock:
            if self.m_process is None:
                return
            try:
                self.m_process.terminate()
                self.m_process.wait(timeout=3.0)
            except Exception:
                self.m_process.kill()
            finally:
                self.m_process = None


class TurnState:
    """
    维护单轮语音交互的状态。

    这里会聚合 SDK 回调出来的所有事件，最终汇总为一轮完整结果，
    包括 `ASR 中间结果`、`LLM 增量输出`、`TTS 流状态` 和最终回复。
    """

    def __init__(self) -> None:
        """
        初始化 TurnState，并保存运行所需依赖。
        """
        self.m_lock = threading.Lock()
        self.reset()

    def reset(self) -> None:
        """
        处理reset。
        """
        with self.m_lock:
            self.m_reply_payload: dict[str, Any] = {}
            self.m_audio_buffer = bytearray()
            self.m_audio_chunk_count = 0
            self.m_asr_partial_list: list[str, Any] = []
            self.m_asr_final_text = ""
            self.m_llm_partial_list: list[str] = []
            self.m_tts_stream_started = False
            self.m_tts_stream_ended = False
            self.m_playback_completed = False
            self.m_audio_stream_started = False
            self.m_endpoint_payload: dict[str, Any] = {}
            self.m_response_event = threading.Event()
            self.m_playback_complete_event = threading.Event()
            self.m_endpoint_event = threading.Event()

    def markAudioStreamStarted(self) -> None:
        """
        处理音频流式started。
        """
        with self.m_lock:
            self.m_audio_stream_started = True

    def markEndpointDetected(self, f_payload: dict[str, Any]) -> None:
        """
        处理endpointdetected。

        参数:
            f_payload: 本次上报的请求载荷。
        """
        with self.m_lock:
            self.m_endpoint_payload = dict(f_payload)
            self.m_endpoint_event.set()

    def addAsrPartial(self, f_text: str) -> None:
        """
        处理ASR增量。

        参数:
            f_text: 待处理的文本内容。
        """
        with self.m_lock:
            self.m_asr_partial_list.append(f_text)

    def setAsrFinal(self, f_text: str) -> None:
        """
        处理ASRfinal。

        参数:
            f_text: 待处理的文本内容。
        """
        with self.m_lock:
            self.m_asr_final_text = f_text

    def addLlmPartial(self, f_delta_text: str) -> None:
        """
        处理LLM增量。

        参数:
            f_delta_text: 待处理的delta文本。
        """
        with self.m_lock:
            self.m_llm_partial_list.append(f_delta_text)

    def markTtsStreamStarted(self) -> None:
        """
        处理TTS流式started。
        """
        with self.m_lock:
            self.m_tts_stream_started = True

    def markTtsStreamEnded(self) -> None:
        """
        处理TTS流式ended。
        """
        with self.m_lock:
            self.m_tts_stream_ended = True

    def markPlaybackCompleted(self) -> None:
        """
        标记本地播放已经完成。
        """
        with self.m_lock:
            self.m_playback_completed = True
            self.m_playback_complete_event.set()

    def setResponse(self, f_payload: dict[str, Any]) -> None:
        """
        处理response。

        参数:
            f_payload: 本次上报的请求载荷。
        """
        with self.m_lock:
            self.m_reply_payload = dict(f_payload)
            self.m_response_event.set()
            if not bool(f_payload.get("tts_streaming", False)):
                self.m_playback_completed = True
                self.m_playback_complete_event.set()

    def appendAudio(self, f_audio_bytes: bytes) -> int:
        """
        处理音频。

        参数:
            f_audio_bytes: 待处理的音频字节数据。

        返回:
            计算得到的数值结果。
        """
        with self.m_lock:
            self.m_audio_buffer.extend(f_audio_bytes)
            self.m_audio_chunk_count += 1
            return self.m_audio_chunk_count

    def wait(self, f_timeout_seconds: float) -> dict[str, Any]:
        """
        处理wait。

        参数:
            f_timeout_seconds: timeoutseconds。

        返回:
            包含处理结果的字典对象。
        """
        t_start_time = time.monotonic()
        if not self.m_response_event.wait(timeout=f_timeout_seconds):
            with self.m_lock:
                t_audio_received = self.m_audio_chunk_count > 0
                t_tts_stream_ended = self.m_tts_stream_ended
            if t_tts_stream_ended and t_audio_received:
                raise TimeoutError("等待 assistant_response 超时：已收到 tts_stream_end 和音频数据")
            raise TimeoutError("等待 assistant_response 超时")
        t_elapsed = time.monotonic() - t_start_time
        t_remaining = max(0.1, f_timeout_seconds - t_elapsed)
        if not self.m_playback_complete_event.wait(timeout=t_remaining):
            with self.m_lock:
                t_tts_stream_ended = self.m_tts_stream_ended
            if t_tts_stream_ended:
                raise TimeoutError("等待本地播放完成超时")
            raise TimeoutError("等待 tts_stream_end 超时")
        with self.m_lock:
            return {
                "reply_payload": dict(self.m_reply_payload),
                "audio_bytes": bytes(self.m_audio_buffer),
                "audio_chunk_count": self.m_audio_chunk_count,
                "audio_stream_started": self.m_audio_stream_started,
                "endpoint_payload": dict(self.m_endpoint_payload),
                "asr_partial_count": len(self.m_asr_partial_list),
                "asr_partials": list(self.m_asr_partial_list),
                "asr_final_text": self.m_asr_final_text,
                "llm_partial_count": len(self.m_llm_partial_list),
                "llm_partial_text": "".join(self.m_llm_partial_list),
                "tts_stream_started": self.m_tts_stream_started,
                "tts_stream_ended": self.m_tts_stream_ended,
                "playback_completed": self.m_playback_completed,
            }


class AgentSdkBinding:
    """
    `AgentSdkBinding` 类。

    功能:
        封装与 `AgentSdkBinding` 相关的职责。
    """
    def __init__(self, f_library_path: Path) -> None:
        """
        初始化 AgentSdkBinding，并保存运行所需依赖。

        参数:
            f_library_path: librarypath。
        """
        self.m_library = ctypes.cdll.LoadLibrary(str(f_library_path))
        self._bindFunctions()

    def _bindFunctions(self) -> None:
        """
        处理functions。
        """
        self.m_library.agentCreateClient.argtypes = [ctypes.POINTER(AgentConfig)]
        self.m_library.agentCreateClient.restype = ctypes.c_void_p
        self.m_library.agentDestroyClient.argtypes = [ctypes.c_void_p]
        self.m_library.agentDestroyClient.restype = None
        self.m_library.agentConnect.argtypes = [ctypes.c_void_p]
        self.m_library.agentConnect.restype = ctypes.c_int
        self.m_library.agentDisconnect.argtypes = [ctypes.c_void_p]
        self.m_library.agentDisconnect.restype = ctypes.c_int
        self.m_library.agentSendAudio.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ubyte), ctypes.c_size_t]
        self.m_library.agentSendAudio.restype = ctypes.c_int
        self.m_library.agentStartAudioStream.argtypes = [ctypes.c_void_p]
        self.m_library.agentStartAudioStream.restype = ctypes.c_int
        self.m_library.agentSendAudioChunk.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ubyte), ctypes.c_size_t]
        self.m_library.agentSendAudioChunk.restype = ctypes.c_int
        self.m_library.agentFinishAudioStream.argtypes = [ctypes.c_void_p]
        self.m_library.agentFinishAudioStream.restype = ctypes.c_int
        self.m_library.agentCancelAudioStream.argtypes = [ctypes.c_void_p]
        self.m_library.agentCancelAudioStream.restype = ctypes.c_int
        self.m_library.agentSetMessageCallback.argtypes = [ctypes.c_void_p, MessageCallbackType, ctypes.c_void_p]
        self.m_library.agentSetStatusCallback.argtypes = [ctypes.c_void_p, StatusCallbackType, ctypes.c_void_p]
        self.m_library.agentSetAudioCallback.argtypes = [ctypes.c_void_p, AudioCallbackType, ctypes.c_void_p]
        self.m_library.agentSetErrorCallback.argtypes = [ctypes.c_void_p, ErrorCallbackType, ctypes.c_void_p]
        if hasattr(self.m_library, "agentSetDeviceSecret"):
            self.m_library.agentSetDeviceSecret.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
            self.m_library.agentSetDeviceSecret.restype = ctypes.c_int
        if hasattr(self.m_library, "agentSetApiBaseUrl"):
            self.m_library.agentSetApiBaseUrl.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
            self.m_library.agentSetApiBaseUrl.restype = ctypes.c_int
        if hasattr(self.m_library, "agentUpdateAuthorization"):
            self.m_library.agentUpdateAuthorization.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
            self.m_library.agentUpdateAuthorization.restype = ctypes.c_int
        if hasattr(self.m_library, "agentCheckDeviceActivation"):
            self.m_library.agentCheckDeviceActivation.argtypes = [ctypes.c_void_p, ctypes.POINTER(AgentDeviceActivationStatus)]
            self.m_library.agentCheckDeviceActivation.restype = ctypes.c_int
        if hasattr(self.m_library, "agentFetchDevicePairingCode"):
            self.m_library.agentFetchDevicePairingCode.argtypes = [ctypes.c_void_p, ctypes.POINTER(AgentDevicePairingCodeResult)]
            self.m_library.agentFetchDevicePairingCode.restype = ctypes.c_int
        if hasattr(self.m_library, "agentFetchDeviceToken"):
            self.m_library.agentFetchDeviceToken.argtypes = [ctypes.c_void_p, ctypes.POINTER(AgentDeviceTokenResult)]
            self.m_library.agentFetchDeviceToken.restype = ctypes.c_int
        if hasattr(self.m_library, "agentEnsureAuthorizedConnection"):
            self.m_library.agentEnsureAuthorizedConnection.argtypes = [
                ctypes.c_void_p,
                ctypes.POINTER(AgentDeviceActivationStatus),
                ctypes.POINTER(AgentDeviceTokenResult),
            ]
            self.m_library.agentEnsureAuthorizedConnection.restype = ctypes.c_int


class VoiceDemoClient:
    """
    `VoiceDemoClient` 类。

    功能:
        封装与 `VoiceDemoClient` 相关的职责。
    """
    def __init__(self, f_args: argparse.Namespace) -> None:
        """
        初始化 VoiceDemoClient，并保存运行所需依赖。

        参数:
            f_args: args。
        """
        self.m_args = f_args
        self.m_turn_state = TurnState()
        self.m_connect_event = threading.Event()
        self.m_error_message = ""
        self.m_binding = AgentSdkBinding(Path(f_args.sdk_library))
        self.m_client = self._createClient()
        self.m_playback_stream = AudioPlaybackStream(f_args.sink_name, f_enabled=not f_args.no_playback)
        self.m_playback_finish_lock = threading.Lock()
        self.m_playback_finish_thread: threading.Thread | None = None
        self._installCallbacks()
        self._configureDeviceLifecycleAccess()
        print(
            "[demo] playback: "
            f"enabled={self.m_playback_stream.isEnabled()}, "
            f"sink={self.m_playback_stream.getSinkName() or '<default>'}"
        )

    def _finishPlaybackAsync(self) -> None:
        """
        异步等待本地播放完成，避免阻塞 SDK 消息回调线程。
        """
        if not self.m_playback_stream.isEnabled():
            self.m_turn_state.markPlaybackCompleted()
            return

        def worker() -> None:
            try:
                self.m_playback_stream.finish()
            except Exception as t_error:
                print(f"[demo] playback_error: {t_error}")
            finally:
                self.m_turn_state.markPlaybackCompleted()

        with self.m_playback_finish_lock:
            if self.m_playback_finish_thread is not None and self.m_playback_finish_thread.is_alive():
                return
            self.m_playback_finish_thread = threading.Thread(
                target=worker,
                name="sdk-playback-finish",
                daemon=True,
            )
            self.m_playback_finish_thread.start()

    def _createClient(self) -> ctypes.c_void_p:
        """
        创建客户端。

        返回:
            ctypescvoidp。
        """
        self.m_config = AgentConfig(
            ws_url=self.m_args.ws_url.encode("utf-8"),
            device_id=self.m_args.device_id.encode("utf-8"),
            client_id=self.m_args.client_id.encode("utf-8"),
            authorization=self.m_args.authorization.encode("utf-8"),
            agent_id=self.m_args.agent_id.encode("utf-8"),
            user_id=self.m_args.user_id.encode("utf-8"),
            tts_tone_id=self.m_args.tts_tone_id.encode("utf-8"),
            audio_format=b"pcm",
            sample_rate=PCM_SAMPLE_RATE,
            channels=PCM_CHANNELS,
            frame_duration_ms=self.m_args.chunk_duration_ms,
            feature_iot=1,
            feature_speaker=1,
            feature_mcp=0,
        )
        t_client = self.m_binding.m_library.agentCreateClient(ctypes.byref(self.m_config))
        if not t_client:
            raise RuntimeError("agentCreateClient 失败")
        return t_client

    def _installCallbacks(self) -> None:
        """
        处理callbacks。
        """
        self.m_message_callback = MessageCallbackType(self._handleMessage)
        self.m_audio_callback = AudioCallbackType(self._handleAudio)
        self.m_status_callback = StatusCallbackType(self._handleStatus)
        self.m_error_callback = ErrorCallbackType(self._handleError)
        self.m_binding.m_library.agentSetMessageCallback(self.m_client, self.m_message_callback, None)
        self.m_binding.m_library.agentSetAudioCallback(self.m_client, self.m_audio_callback, None)
        self.m_binding.m_library.agentSetStatusCallback(self.m_client, self.m_status_callback, None)
        self.m_binding.m_library.agentSetErrorCallback(self.m_client, self.m_error_callback, None)

    def _configureDeviceLifecycleAccess(self) -> None:
        """
        设置设备生命周期接口所需的密钥与 API 地址。
        """
        if self.m_args.device_secret:
            if not hasattr(self.m_binding.m_library, "agentSetDeviceSecret"):
                raise RuntimeError("当前 SDK 动态库不支持 agentSetDeviceSecret，请先重建 SDK")
            t_result = int(
                self.m_binding.m_library.agentSetDeviceSecret(
                    self.m_client,
                    self.m_args.device_secret.encode("utf-8"),
                )
            )
            if t_result != 0:
                raise RuntimeError(f"agentSetDeviceSecret 失败: {t_result}")
        if self.m_args.api_base_url:
            if not hasattr(self.m_binding.m_library, "agentSetApiBaseUrl"):
                raise RuntimeError("当前 SDK 动态库不支持 agentSetApiBaseUrl，请先重建 SDK")
            t_result = int(
                self.m_binding.m_library.agentSetApiBaseUrl(
                    self.m_client,
                    self.m_args.api_base_url.encode("utf-8"),
                )
            )
            if t_result != 0:
                raise RuntimeError(f"agentSetApiBaseUrl 失败: {t_result}")

    @staticmethod
    def _decodeFixedText(f_value: bytes | bytearray) -> str:
        t_raw_bytes = bytes(f_value)
        return t_raw_bytes.split(b"\x00", 1)[0].decode("utf-8", errors="replace")

    def checkDeviceActivation(self) -> dict[str, Any]:
        """
        调用 SDK 检查设备激活状态。
        """
        if not hasattr(self.m_binding.m_library, "agentCheckDeviceActivation"):
            raise RuntimeError("当前 SDK 动态库不支持 agentCheckDeviceActivation，请先重建 SDK")
        t_status = AgentDeviceActivationStatus()
        t_result = int(self.m_binding.m_library.agentCheckDeviceActivation(self.m_client, ctypes.byref(t_status)))
        if t_result != 0:
            raise RuntimeError(f"agentCheckDeviceActivation 失败: {t_result}")
        return {
            "device_id": self._decodeFixedText(t_status.m_device_id),
            "status": self._decodeFixedText(t_status.m_status),
            "setup_status": self._decodeFixedText(t_status.m_setup_status),
            "current_agent_id": self._decodeFixedText(t_status.m_current_agent_id),
            "activated": bool(t_status.m_activated_flag),
            "bound": bool(t_status.m_bound_flag),
            "can_request_pairing_code": bool(t_status.m_can_request_pairing_code_flag),
        }

    def fetchDevicePairingCode(self) -> dict[str, Any]:
        """
        调用 SDK 申请设备配对码。
        """
        if not hasattr(self.m_binding.m_library, "agentFetchDevicePairingCode"):
            raise RuntimeError("当前 SDK 动态库不支持 agentFetchDevicePairingCode，请先重建 SDK")
        t_pairing_result = AgentDevicePairingCodeResult()
        t_result = int(self.m_binding.m_library.agentFetchDevicePairingCode(self.m_client, ctypes.byref(t_pairing_result)))
        if t_result != 0:
            raise RuntimeError(f"agentFetchDevicePairingCode 失败: {t_result}")
        return {
            "device_id": self._decodeFixedText(t_pairing_result.m_device_id),
            "pairing_code": self._decodeFixedText(t_pairing_result.m_pairing_code),
            "pairing_expires_at": self._decodeFixedText(t_pairing_result.m_pairing_expires_at),
            "status": self._decodeFixedText(t_pairing_result.m_status),
            "scene": self._decodeFixedText(t_pairing_result.m_scene),
        }

    def fetchDeviceToken(self) -> dict[str, Any]:
        """
        调用 SDK 获取设备 token。
        """
        if not hasattr(self.m_binding.m_library, "agentFetchDeviceToken"):
            raise RuntimeError("当前 SDK 动态库不支持 agentFetchDeviceToken，请先重建 SDK")
        t_token_result = AgentDeviceTokenResult()
        t_result = int(self.m_binding.m_library.agentFetchDeviceToken(self.m_client, ctypes.byref(t_token_result)))
        if t_result != 0:
            raise RuntimeError(f"agentFetchDeviceToken 失败: {t_result}")
        return {
            "token_type": self._decodeFixedText(t_token_result.m_token_type),
            "access_token": self._decodeFixedText(t_token_result.m_access_token),
            "expires_in": int(t_token_result.m_expires_in),
            "device_id": self._decodeFixedText(t_token_result.m_device_id),
        }

    def waitForBinding(self, f_timeout_seconds: float, f_poll_interval_seconds: float) -> dict[str, Any]:
        """
        轮询等待设备完成绑定。
        """
        if f_timeout_seconds <= 0:
            raise TimeoutError("等待绑定超时时间必须大于 0")
        t_deadline = time.monotonic() + f_timeout_seconds
        t_last_signature: tuple[Any, ...] | None = None
        while True:
            t_status = self.checkDeviceActivation()
            t_signature = (
                t_status["status"],
                t_status["setup_status"],
                t_status["activated"],
                t_status["bound"],
                t_status["current_agent_id"],
            )
            if t_signature != t_last_signature:
                print(f"[demo] activation_status: {json.dumps(t_status, ensure_ascii=False)}")
                t_last_signature = t_signature
            if t_status["activated"] and t_status["bound"]:
                print("[demo] device_binding_ready=true")
                return t_status
            if time.monotonic() >= t_deadline:
                raise TimeoutError("等待用户完成设备绑定超时")
            time.sleep(max(0.5, f_poll_interval_seconds))

    def runAutomaticDeviceFlow(self) -> dict[str, Any]:
        """
        自动执行设备检查、配对码申请和绑定等待。
        """
        t_status = self.checkDeviceActivation()
        print(f"[demo] activation_status: {json.dumps(t_status, ensure_ascii=False)}")
        if t_status["activated"] and t_status["bound"]:
            print("[demo] device_already_bound=true")
            return t_status
        if not self.m_args.device_secret:
            raise RuntimeError("自动设备流程需要提供 device_secret")
        if not t_status["can_request_pairing_code"]:
            raise RuntimeError("当前设备状态不允许申请配对码")
        t_pairing_result = self.fetchDevicePairingCode()
        print(f"[demo] pairing_code: {json.dumps(t_pairing_result, ensure_ascii=False)}")
        print("[demo] 请在 Web 端使用当前配对码绑定设备，脚本会自动轮询等待绑定完成。")
        return self.waitForBinding(self.m_args.pairing_wait_timeout, self.m_args.pairing_poll_interval)

    def _handleMessage(self, f_message: bytes | None, _: Any) -> None:
        """
        处理message。

        参数:
            f_message: message。
            _: _。
        """
        if not f_message:
            return
        try:
            t_payload = json.loads(f_message.decode("utf-8"))
        except Exception:
            print(f"[demo] 无法解析消息: {f_message!r}")
            return

        t_message_type = str(t_payload.get("type", "")).strip()
        if t_message_type == "session_ready":
            print(f"[demo] session_ready: session_id={t_payload.get('session_id', '')}")
            return
        if t_message_type == "hello":
            print(f"[demo] hello_audio: {json.dumps(t_payload.get('audio', {}), ensure_ascii=False)}")
            return
        if t_message_type == "audio_stream_started":
            self.m_turn_state.markAudioStreamStarted()
            print("[demo] audio_stream_started")
            return
        if t_message_type == "audio_stream_endpoint_detected":
            self.m_turn_state.markEndpointDetected(t_payload)
            print(
                "[demo] audio_stream_endpoint_detected: "
                f"reason={t_payload.get('reason', '')}, "
                f"voice_chunk_count={t_payload.get('voice_chunk_count', 0)}, "
                f"silence_chunk_count={t_payload.get('silence_chunk_count', 0)}"
            )
            return
        if t_message_type == "asr_partial":
            t_text = str(t_payload.get("text", "")).strip()
            self.m_turn_state.addAsrPartial(t_text)
            print(f"[demo] asr_partial: {t_text}")
            return
        if t_message_type == "asr_final":
            t_text = str(t_payload.get("text", "")).strip()
            self.m_turn_state.setAsrFinal(t_text)
            print(f"[demo] asr_final: {t_text}")
            return
        if t_message_type == "llm_partial":
            t_delta_text = str(t_payload.get("delta_text", ""))
            self.m_turn_state.addLlmPartial(t_delta_text)
            print(f"[demo] llm_partial: {t_delta_text}")
            return
        if t_message_type == "tts_stream_start":
            self.m_turn_state.markTtsStreamStarted()
            try:
                self.m_playback_stream.start()
            except Exception as t_error:
                print(f"[demo] playback_error: {t_error}")
            print(f"[demo] tts_stream_start: format={t_payload.get('audio_format', '')}")
            return
        if t_message_type == "tts_stream_end":
            self.m_turn_state.markTtsStreamEnded()
            self._finishPlaybackAsync()
            print(
                "[demo] tts_stream_end: "
                f"status={t_payload.get('status', '')}, "
                f"chunk_count={t_payload.get('chunk_count', 0)}, "
                f"audio_bytes_length={t_payload.get('audio_bytes_length', 0)}"
            )
            return
        if t_message_type == "assistant_response":
            self.m_turn_state.setResponse(t_payload)
            print(f"[demo] assistant_text: {str(t_payload.get('text', '')).strip()}")
            print(f"[demo] assistant_intent: {t_payload.get('intent', '')}")
            print(f"[demo] asr_text: {str(t_payload.get('asr_text', '')).strip()}")
            print(f"[demo] stream_mode: {bool(t_payload.get('stream_mode', False))}")
            print(f"[demo] tts_streaming: {bool(t_payload.get('tts_streaming', False))}")
            print(f"[demo] tts_stream_chunk_count: {int(t_payload.get('tts_stream_chunk_count', 0))}")
            return
        if t_message_type == "iot":
            print(f"[demo] iot_event: {json.dumps(t_payload, ensure_ascii=False)}")
            return
        if t_message_type == "error":
            print(f"[demo] server_error: {json.dumps(t_payload, ensure_ascii=False)}")
            return
        print(f"[demo] 未知消息: {json.dumps(t_payload, ensure_ascii=False)}")

    def _handleAudio(self, f_data: Any, f_size: int, _: Any) -> None:
        """
        处理音频。

        参数:
            f_data: data。
            f_size: size。
            _: _。
        """
        if not f_data or f_size <= 0:
            return
        t_audio_bytes = ctypes.string_at(f_data, f_size)
        t_chunk_count = self.m_turn_state.appendAudio(t_audio_bytes)
        try:
            self.m_playback_stream.write(t_audio_bytes)
        except Exception as t_error:
            print(f"[demo] playback_error: {t_error}")
            self.m_playback_stream.abort()
        if t_chunk_count <= 3 or t_chunk_count % 20 == 0:
            print(f"[demo] audio_chunk: count={t_chunk_count}, bytes={len(t_audio_bytes)}")

    def _handleStatus(self, f_status: int, _: Any) -> None:
        """
        处理status。

        参数:
            f_status: status。
            _: _。
        """
        t_label_map = {
            AGENT_STATUS_DISCONNECTED: "DISCONNECTED",
            AGENT_STATUS_CONNECTING: "CONNECTING",
            AGENT_STATUS_CONNECTED: "CONNECTED",
        }
        print(f"[demo] sdk_status: {t_label_map.get(int(f_status), str(f_status))}")
        if int(f_status) == AGENT_STATUS_CONNECTED:
            self.m_connect_event.set()

    def _handleError(self, f_error_code: int, f_message: bytes | None, _: Any) -> None:
        """
        处理error。

        参数:
            f_error_code: errorcode。
            f_message: message。
            _: _。
        """
        t_message = ""
        if f_message:
            t_message = f_message.decode("utf-8", errors="replace")
        self.m_error_message = f"error_code={f_error_code}, message={t_message}"
        print(f"[demo] sdk_error: {self.m_error_message}")

    def connect(self) -> None:
        """
        处理connect。
        """
        if self.m_args.ensure_device_auth:
            if not hasattr(self.m_binding.m_library, "agentEnsureAuthorizedConnection"):
                raise RuntimeError("当前 SDK 动态库不支持 agentEnsureAuthorizedConnection，请先重建 SDK")
            t_status = AgentDeviceActivationStatus()
            t_token = AgentDeviceTokenResult()
            t_result = int(
                self.m_binding.m_library.agentEnsureAuthorizedConnection(
                    self.m_client,
                    ctypes.byref(t_status),
                    ctypes.byref(t_token),
                )
            )
            if t_result != 0:
                raise RuntimeError(f"agentEnsureAuthorizedConnection 失败: {t_result}")
            print(
                "[demo] ensured_device_auth: "
                f"device_id={self._decodeFixedText(t_status.m_device_id)}, "
                f"activated={bool(t_status.m_activated_flag)}, "
                f"bound={bool(t_status.m_bound_flag)}, "
                f"expires_in={int(t_token.m_expires_in)}"
            )
        else:
            t_result = int(self.m_binding.m_library.agentConnect(self.m_client))
            if t_result != 0:
                raise RuntimeError(f"agentConnect 失败: {t_result}")
        if not self.m_connect_event.wait(timeout=self.m_args.connect_timeout):
            raise TimeoutError("等待 SDK 建连成功超时")

    def disconnect(self) -> None:
        """
        处理disconnect。
        """
        try:
            self.m_playback_stream.abort()
            self.m_binding.m_library.agentDisconnect(self.m_client)
        finally:
            self.m_binding.m_library.agentDestroyClient(self.m_client)

    def _callSdk(self, f_function_name: str, *f_args: Any) -> None:
        """
        处理sdk。

        参数:
            f_function_name: function名称。
            f_args: args。
        """
        t_result = int(getattr(self.m_binding.m_library, f_function_name)(self.m_client, *f_args))
        if t_result != 0:
            raise RuntimeError(f"{f_function_name} 失败: {t_result}")

    def sendAudioTurnStream(self, f_audio_bytes: bytes) -> dict[str, Any]:
        """
        处理音频turn流式。

        参数:
            f_audio_bytes: 待处理的音频字节数据。

        返回:
            包含处理结果的字典对象。
        """
        if not f_audio_bytes:
            raise ValueError("音频数据不能为空")

        self.m_turn_state.reset()
        self._callSdk("agentStartAudioStream")
        t_send_interval_seconds = max(0.0, self.m_args.send_pace_ms / 1000.0)
        try:
            for t_offset in range(0, len(f_audio_bytes), PCM_FRAME_BYTES):
                t_chunk = f_audio_bytes[t_offset:t_offset + PCM_FRAME_BYTES]
                if not t_chunk:
                    continue
                t_buffer = (ctypes.c_ubyte * len(t_chunk)).from_buffer_copy(t_chunk)
                self._callSdk("agentSendAudioChunk", t_buffer, len(t_chunk))
                if t_send_interval_seconds > 0:
                    time.sleep(t_send_interval_seconds)
            self._callSdk("agentFinishAudioStream")
            return self.m_turn_state.wait(self.m_args.turn_timeout)
        except Exception:
            try:
                self.m_binding.m_library.agentCancelAudioStream(self.m_client)
            except Exception:
                pass
            self.m_playback_stream.abort()
            raise

    def sendMicrophoneTurnStream(self) -> dict[str, Any]:
        """
        直接从本地麦克风边录边发。

        交互模式下优先依赖服务端 `audio_stream_endpoint_detected` 自动收尾，
        同时增加本地最大录音时长兜底，避免服务端未截断时无限录音。
        """

        self.m_turn_state.reset()
        self._callSdk("agentStartAudioStream")
        t_process = startRecorderProcess(self.m_args.source_name)
        t_recorder_stopped = False
        t_recorded_pcm_bytes = 0
        t_deadline: float | None = None
        if self.m_args.record_seconds > 0:
            t_deadline = time.monotonic() + self.m_args.record_seconds
            print(f"[demo] recording_seconds={self.m_args.record_seconds:.1f}")
        else:
            t_max_record_seconds = max(1.0, float(self.m_args.max_record_seconds))
            t_deadline = time.monotonic() + t_max_record_seconds
            print("[demo] recording_until_endpoint=true")
            print(f"[demo] max_record_seconds={t_max_record_seconds:.1f}")
            print("[demo] 已开始录音，请讲话；服务端检测到停讲或本地超时后会自动结束本轮录音。")

        try:
            while True:
                if self.m_turn_state.m_endpoint_event.is_set():
                    break
                if t_deadline is not None and time.monotonic() >= t_deadline:
                    print("[demo] local_record_timeout_reached")
                    break
                t_chunk = t_process.stdout.read(PCM_FRAME_BYTES)
                if not t_chunk:
                    break
                t_recorded_pcm_bytes += len(t_chunk)
                t_buffer = (ctypes.c_ubyte * len(t_chunk)).from_buffer_copy(t_chunk)
                self._callSdk("agentSendAudioChunk", t_buffer, len(t_chunk))

            stopRecorderProcess(t_process)
            t_recorder_stopped = True
            print(f"[demo] recorded_pcm_bytes={t_recorded_pcm_bytes}")
            self._callSdk("agentFinishAudioStream")
            return self.m_turn_state.wait(self.m_args.turn_timeout)
        except Exception:
            try:
                self.m_binding.m_library.agentCancelAudioStream(self.m_client)
            except Exception:
                pass
            self.m_playback_stream.abort()
            raise
        finally:
            if not t_recorder_stopped:
                stopRecorderProcess(t_process)


def runCommand(f_command: list[str], f_input: bytes | None = None) -> bytes:
    """
    执行command。

    参数:
        f_command: command。
        f_input: input。

    返回:
        bytes。
    """
    t_process = subprocess.run(
        f_command,
        input=f_input,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if t_process.returncode != 0:
        t_stderr = t_process.stderr.decode("utf-8", errors="replace")
        raise RuntimeError(f"命令执行失败: {' '.join(f_command)}\n{t_stderr}")
    return t_process.stdout


def listPulseDevices() -> None:
    """
    列出pulsedevices。
    """
    for t_command in (
        ["pactl", "info"],
        ["pactl", "list", "short", "sources"],
        ["pactl", "list", "short", "sinks"],
    ):
        print(f"[demo] exec: {' '.join(t_command)}")
        try:
            t_output = runCommand(t_command)
        except Exception as t_error:
            print(f"[demo] exec_failed: {t_error}")
            continue
        print(t_output.decode("utf-8", errors="replace"))


def getPulseDeviceNames(f_device_type: str) -> list[str]:
    """
    获取 Pulse 设备名称列表。

    参数:
        f_device_type: sources 或 sinks。

    返回:
        list[str]。
    """
    if f_device_type not in ("sources", "sinks"):
        raise ValueError(f"不支持的 Pulse 设备类型: {f_device_type}")
    t_output = runCommand(["pactl", "list", "short", f_device_type])
    t_device_name_list: list[str] = []
    for t_line in t_output.decode("utf-8", errors="replace").splitlines():
        t_parts = t_line.split("\t")
        if len(t_parts) >= 2 and t_parts[1].strip():
            t_device_name_list.append(t_parts[1].strip())
    return t_device_name_list


def validatePulseDeviceSelection(f_args: argparse.Namespace) -> None:
    """
    校验用户指定的 Pulse 输入输出设备是否存在。

    参数:
        f_args: 命令行参数。
    """
    if f_args.source_name:
        t_source_name_list = getPulseDeviceNames("sources")
        if f_args.source_name not in t_source_name_list:
            raise RuntimeError(
                "指定的 Pulse 输入源不存在: "
                f"{f_args.source_name}，可用输入源: {', '.join(t_source_name_list) or '<none>'}"
            )
    if not f_args.no_playback and f_args.sink_name:
        t_sink_name_list = getPulseDeviceNames("sinks")
        if f_args.sink_name not in t_sink_name_list:
            raise RuntimeError(
                "指定的 Pulse 输出设备不存在: "
                f"{f_args.sink_name}，可用输出设备: {', '.join(t_sink_name_list) or '<none>'}"
            )


def generateSyntheticAudio(f_seconds: float) -> bytes:
    """
    生成synthetic音频。

    参数:
        f_seconds: seconds。

    返回:
        bytes。
    """
    t_total_samples = max(1, int(PCM_SAMPLE_RATE * f_seconds))
    t_audio = bytearray()
    for t_index in range(t_total_samples):
        t_time = t_index / float(PCM_SAMPLE_RATE)
        t_value = int(10000 * math.sin(2.0 * math.pi * 440.0 * t_time))
        t_audio.extend(int(t_value).to_bytes(2, byteorder="little", signed=True))
    return bytes(t_audio)


def loadPcmFile(f_pcm_file: str) -> bytes:
    """
    加载PCMfile。

    参数:
        f_pcm_file: PCMfile。

    返回:
        bytes。
    """
    t_audio_path = Path(f_pcm_file).expanduser().resolve()
    if not t_audio_path.is_file():
        raise FileNotFoundError(f"PCM 文件不存在: {t_audio_path}")
    t_audio_bytes = t_audio_path.read_bytes()
    if len(t_audio_bytes) < PCM_FRAME_BYTES:
        raise RuntimeError(f"PCM 文件过小: {t_audio_path}")
    print(f"[demo] pcm_file: {t_audio_path} ({len(t_audio_bytes)} bytes)")
    return t_audio_bytes


def startRecorderProcess(f_source_name: str) -> subprocess.Popen[bytes]:
    """
    处理recorderprocess。

    参数:
        f_source_name: source名称。

    返回:
        subprocesspopenbytes。
    """
    t_command = [
        "parec",
        "--raw",
        "--format=s16le",
        f"--rate={PCM_SAMPLE_RATE}",
        f"--channels={PCM_CHANNELS}",
        "--latency-msec=20",
    ]
    if f_source_name:
        t_command.extend(["-d", f_source_name])

    return subprocess.Popen(
        t_command,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        stdin=subprocess.DEVNULL,
        preexec_fn=os.setsid,
    )


def stopRecorderProcess(f_process: subprocess.Popen[bytes]) -> None:
    """
    处理recorderprocess。

    参数:
        f_process: process。
    """
    try:
        os.killpg(os.getpgid(f_process.pid), signal.SIGTERM)
    except Exception:
        f_process.terminate()
    try:
        f_process.wait(timeout=2.0)
    except Exception:
        f_process.kill()


def buildParser() -> argparse.ArgumentParser:
    """
    构建parser。

    返回:
        argparseargumentparser。
    """
    t_parser = argparse.ArgumentParser(description="童趣 SDK 语音演示程序")
    t_parser.add_argument("--sdk-library", default="/opt/agent_sdk/lib/libagent_sdk.so")
    t_parser.add_argument("--ws-url", default=os.environ.get("AGENT_WS_URL", "ws://tongqu-server:8765/ws/v1/chat"))
    t_parser.add_argument("--api-base-url", default=os.environ.get("VOICE_DEMO_API_BASE_URL", ""))
    t_parser.add_argument("--device-id", default=os.environ.get("VOICE_DEMO_DEVICE_ID", ""))
    t_parser.add_argument("--device-secret", default=os.environ.get("VOICE_DEMO_DEVICE_SECRET", ""))
    t_parser.add_argument("--client-id", default=os.environ.get("VOICE_DEMO_CLIENT_ID", "voice-demo-client-001"))
    t_parser.add_argument("--authorization", default=os.environ.get("VOICE_DEMO_AUTHORIZATION", ""))
    t_parser.add_argument("--agent-id", default=os.environ.get("VOICE_DEMO_AGENT_ID", ""))
    t_parser.add_argument("--user-id", default=os.environ.get("VOICE_DEMO_USER_ID", ""))
    t_parser.add_argument("--tts-tone-id", default=os.environ.get("VOICE_DEMO_TTS_TONE_ID", ""))
    t_parser.add_argument("--source-name", default=os.environ.get("SDK_AUDIO_SOURCE", ""))
    t_parser.add_argument("--sink-name", default=os.environ.get("SDK_AUDIO_SINK", ""))
    t_parser.add_argument("--connect-timeout", type=float, default=10.0)
    t_parser.add_argument("--turn-timeout", type=float, default=60.0)
    t_parser.add_argument("--record-seconds", type=float, default=0.0)
    t_parser.add_argument("--max-record-seconds", type=float, default=float(os.environ.get("SDK_STREAMING_DEMO_MAX_RECORD_SECONDS", "12")))
    t_parser.add_argument("--pcm-file", default=os.environ.get("VOICE_DEMO_PCM_FILE", ""))
    t_parser.add_argument("--synthetic-input", action="store_true")
    t_parser.add_argument("--synthetic-seconds", type=float, default=1.2)
    t_parser.add_argument("--chunk-duration-ms", type=int, default=PCM_FRAME_DURATION_MS)
    t_parser.add_argument("--send-pace-ms", type=float, default=float(PCM_FRAME_DURATION_MS))
    t_parser.add_argument("--list-devices", action="store_true")
    t_parser.add_argument("--check-activation-only", action="store_true")
    t_parser.add_argument("--fetch-pairing-code-only", action="store_true")
    t_parser.add_argument("--fetch-device-token-only", action="store_true")
    t_parser.add_argument("--auto-device-flow", action="store_true")
    t_parser.add_argument("--pairing-wait-timeout", type=float, default=300.0)
    t_parser.add_argument("--pairing-poll-interval", type=float, default=3.0)
    t_parser.add_argument("--ensure-device-auth", action="store_true")
    t_parser.add_argument("--once", action="store_true")
    t_parser.add_argument("--no-playback", action="store_true")
    return t_parser


def chooseInputAudio(f_args: argparse.Namespace) -> bytes:
    """
    处理input音频。

    参数:
        f_args: args。

    返回:
        bytes。
    """
    if f_args.pcm_file:
        return loadPcmFile(f_args.pcm_file)
    if f_args.synthetic_input:
        print(f"[demo] 生成合成测试音频 {f_args.synthetic_seconds:.1f} 秒")
        return generateSyntheticAudio(f_args.synthetic_seconds)
    raise RuntimeError("chooseInputAudio 仅用于文件或合成音频输入")


def printTurnSummary(f_turn_result: dict[str, Any]) -> None:
    """
    处理turn摘要。

    参数:
        f_turn_result: turnresult。
    """
    t_reply_payload = dict(f_turn_result["reply_payload"])
    t_endpoint_payload = dict(f_turn_result.get("endpoint_payload", {}))
    print("[demo] ---------------- turn summary ----------------")
    print(f"[demo] audio_stream_started={f_turn_result['audio_stream_started']}")
    print(f"[demo] endpoint_detected={bool(t_endpoint_payload)}")
    print(f"[demo] endpoint_reason={str(t_endpoint_payload.get('reason', ''))}")
    print(f"[demo] asr_partial_count={f_turn_result['asr_partial_count']}")
    print(f"[demo] asr_final_text={f_turn_result['asr_final_text']}")
    print(f"[demo] llm_partial_count={f_turn_result['llm_partial_count']}")
    print(f"[demo] llm_partial_text={f_turn_result['llm_partial_text']}")
    print(f"[demo] tts_stream_started={f_turn_result['tts_stream_started']}")
    print(f"[demo] tts_stream_ended={f_turn_result['tts_stream_ended']}")
    print(f"[demo] playback_completed={f_turn_result['playback_completed']}")
    print(f"[demo] audio_chunk_count={f_turn_result['audio_chunk_count']}")
    print(f"[demo] audio_bytes={len(f_turn_result['audio_bytes'])}")
    print(f"[demo] assistant_text={str(t_reply_payload.get('text', '')).strip()}")
    print(f"[demo] assistant_intent={t_reply_payload.get('intent', '')}")
    print(f"[demo] tts_stream_chunk_count={int(t_reply_payload.get('tts_stream_chunk_count', 0))}")
    print(f"[demo] audio_bytes_length={int(t_reply_payload.get('audio_bytes_length', 0))}")
    print("[demo] ------------------------------------------------")


def main() -> int:
    """
    处理main。

    返回:
        计算得到的数值结果。
    """
    t_args = buildParser().parse_args()

    if t_args.chunk_duration_ms <= 0:
        raise ValueError("chunk_duration_ms 必须大于 0")
    if t_args.list_devices:
        listPulseDevices()
        return 0
    validatePulseDeviceSelection(t_args)

    t_client = VoiceDemoClient(t_args)
    try:
        listPulseDevices()
        if t_args.check_activation_only:
            print(f"[demo] activation_status: {json.dumps(t_client.checkDeviceActivation(), ensure_ascii=False)}")
            return 0
        if t_args.fetch_pairing_code_only:
            print(f"[demo] pairing_code: {json.dumps(t_client.fetchDevicePairingCode(), ensure_ascii=False)}")
            return 0
        if t_args.fetch_device_token_only:
            print(f"[demo] device_token: {json.dumps(t_client.fetchDeviceToken(), ensure_ascii=False)}")
            return 0
        if t_args.auto_device_flow:
            t_client.runAutomaticDeviceFlow()
            t_args.ensure_device_auth = True
        t_client.connect()
        print("[demo] connected, streaming demo ready")

        while True:
            if t_args.pcm_file or t_args.synthetic_input:
                t_audio_bytes = chooseInputAudio(t_args)
                if not t_audio_bytes:
                    break
                t_turn_result = t_client.sendAudioTurnStream(t_audio_bytes)
            elif sys.stdin.isatty():
                t_command = input("[demo] 输入 q 退出，直接回车开始录音: ").strip().lower()
                if t_command in {"q", "quit", "exit"}:
                    break
                t_turn_result = t_client.sendMicrophoneTurnStream()
            else:
                if t_args.record_seconds <= 0:
                    raise RuntimeError("非交互模式下请显式传入 --record-seconds、--pcm-file 或 --synthetic-input")
                t_turn_result = t_client.sendMicrophoneTurnStream()
            printTurnSummary(t_turn_result)
            if t_args.once or t_args.synthetic_input or t_args.pcm_file:
                break
    finally:
        t_client.disconnect()
    return 0


if __name__ == "__main__":
    sys.exit(main())
