# rockchip830 SDK 语音验证包

作者: hh-zyb

## 1. 包内容

- `lib/`
  - `libagent_sdk.so`
  - `libwebsockets.so*`
  - `libcurl.so*`
- `scripts/sdk_voice_demo_remote.sh`
- `tools/sdk_voice_demo/sdk_voice_chat_demo.py`
- `run_public_voice_demo.sh`

## 2. 目标环境要求

- 目标设备 CPU/ABI 需要兼容 `arm-rockchip830-linux-uclibcgnueabihf`
- 目标系统需要提供兼容的 `libc.so.0`
- 目标系统需要具备 `python3`
- 如需麦克风/扬声器演示，目标系统还需要具备 `parec` / `pacat`

如果目标系统不是 `uClibc` ARM 环境，这个运行包不能直接执行。

## 3. 推荐验证方式

### 3.1 合成音频单轮验证

```bash
bash run_public_voice_demo.sh \
  --ws-url wss://tongqu.zworker.online/ws/v1/chat \
  --api-base-url https://tongqu.zworker.online \
  --device-id <device_id> \
  --device-secret <device_secret> \
  --synthetic-input \
  --no-playback \
  --once
```

### 3.2 本地 PCM 文件验证

```bash
bash run_public_voice_demo.sh \
  --ws-url wss://tongqu.zworker.online/ws/v1/chat \
  --api-base-url https://tongqu.zworker.online \
  --device-id <device_id> \
  --device-secret <device_secret> \
  --pcm-file /path/to/demo_input.pcm \
  --no-playback \
  --once
```

### 3.3 麦克风验证

```bash
bash run_public_voice_demo.sh \
  --ws-url wss://tongqu.zworker.online/ws/v1/chat \
  --api-base-url https://tongqu.zworker.online \
  --device-id <device_id> \
  --device-secret <device_secret> \
  --record-seconds 5
```

## 4. 成功标志

日志中至少应出现：

- `session_ready`
- `hello_audio`
- `asr_final`
- `assistant_text`
- `tts_stream_end`
